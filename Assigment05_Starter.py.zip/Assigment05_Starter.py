# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   COLE PHALEN, Added code to complete assignment 5
# https://www.tutorialspoint.com/python/python_dictionary.htm

# https://github.com/onebigtruck/IntroToProg-Python

# -------------------------------------------------#


strData = ""
dicRow = {}
lstTable = []

# Step 1 - Load data from a file

with open('ToDo.txt', 'r+') as ToDo:
    for line in ToDo:  # loops through each line in txt file
        key = line.split(",")[0]  # splits each line into a small two item list, one item per side of the comma, uses
        # \n first item
        val = line.strip('\n').split(",")[1]  # removes the new-line symbol and again makes a small list but uses
        # \n the second item
        dicRow = {key: val}  # adds each of these items as the key and value in a dictionary, respectively
        lstTable.append(dicRow)  # adds these dictionaries as new 'rows' in the list


# Step 2 - Display a menu of choices to the user
    while True:
        print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
        strChoice = str(input("Which option would you like to perform? [1 to 4] - \n"))
        print()  # adding a new line

    # Step 3 -Show the current items in the table
        if strChoice == '1':
            for dicRow in lstTable:  # turn the list of dictionaries into strings
                strData = str(dicRow)  # makes dictionary into a string
                strData = strData.strip('{}')  # removes curly brackets from sting/dictionary
                strData = strData.replace("'", '')  # removes quotation marks
                strData = strData.replace(':', ',')  # replaces colon with comma to match formatting
                print(strData)  # displays the current contents of txt file
                continue

    # Step 4 - Add a new item to the list/Table
        elif strChoice.strip() == '2':
            opt2 = str(input('What would you like to add? '))  # asks what task user would like to add
            opt20 = str(input("What is it's priority? "))  # asks its priority
            dicRow = {opt2: opt20}  # adds these inputs to dictionary
            lstTable.append(dicRow)  # adds dictionary to list
            continue

    # Step 5 - Remove a new item to the list/Table
        elif strChoice == '3':
            lstTable.pop(int(input('Which item would you like to remove? \n\t-Select using its number in list ')) - 1)
            # takes a user input integer and removes uses it to remove an item from list
            continue

    # Step 6 - Save tasks to the txt file
        elif strChoice == '4':
            ToDo = open('ToDo.txt', 'w')
            for dicRow in lstTable:  # turn the list of dictionaries into strings
                strData = str(dicRow)  # makes dictionary into a string
                strData = strData.strip('{}')  # removes curly brackets from sting/dictionary
                strData = strData.replace("'", '')
                strData = strData.replace(':', ',')
                strData = strData + '\n'
                ToDo.write(strData)
            continue

        elif strChoice == '5':
            break  # and Exit the program

