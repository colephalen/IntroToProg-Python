dicRow = {}
lstTable = []
strData = ""
with open('ToDo.txt', 'r+') as ToDo:

    line1 = ToDo.readline()  # reads first line
    line1 = line1.strip('\n')  # removes the \n after the first line
    S_line = line1.split(',')  # makes a list of the two items in the line
    key = S_line[0]  # grabs first item to be used as a key in dictionary
    val = S_line[1]  # grabs second item to be used as a value in dictionary
    dicRow[key] = val   # makes a dictionary using the key and value established above
    lstTable.append(dicRow)  # throws the dictionary into the list

    line2 = ToDo.readline()  # reads next line and the following lines repeat the same methods as above
    S2_line = line2.split(',')
    key = S2_line[0]
    val = S2_line[1]
    dicRow = {key: val}

    lstTable.append(dicRow)  # throws the second dictionary into the list

    print(lstTable)

    for dicRow in lstTable:  # turn the list of dictionaries into strings
        strData = str(dicRow)  # makes dictionary into a string
        strData = strData.strip('{}')  # removes curly brackets from sting/dictionary
        strData = strData.replace("'", '')
        strData = strData.replace(':', ',')
        print(strData)

    #lstTable.append(dicRow)

    # dicRow['Pay Bills'] = 'High'  # uses second item in list as a value in dictionary
    # lstTable.append(dicRow)


    # line2 = ToDo.readline()
    # hhh = line1 + line2
    # print(hhh)





'''    
    app = open('Todo.txt', 'a')
    a = 'Clean House, Low\n'
    b = 'Pay Bills, High\n'

    ToDo.write(a)
    app.write(b)


D = {}
var1 = 'Niall'
var2 = 'Friend'
D[var1] = var2
D['Jane'] = 'gf'

print(D)




'''



    #for line in h:
        #print(line)

